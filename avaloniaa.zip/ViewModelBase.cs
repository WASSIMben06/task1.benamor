﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AvaloniaApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
